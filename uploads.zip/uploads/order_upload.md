# Order CSV file format
The first line of your order CSV has to include the field headers described below with each separated by a comma. Subsequent lines in the file should contain data for your order using those same fields in that exact same order. Here's a description of each field:
